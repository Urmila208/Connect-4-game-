# Welcome to Connect4 Java
This is a Connect 4 game that I made in Java, and posted a video explaining the code on youtube. You can find this video [here](https://youtu.be/E6TPk2GVuIY).
